# Lua and NeoVim

## Lua Features of NeoVim

## Lua Plugins for NeoVim

- https://github.com/kyazdani42/nvim-tree
- https://github.com/kyazdani42/nvim-web-devicons
-
