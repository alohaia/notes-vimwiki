# Real-time PCR，实时荧光定量PRC技术

- [引物类实时PCR](引物类实时PCR.md)
- [非引物探针类实时PRC](非引物探针类实时PRC.md)

See Also: [荧光素酶](荧光素酶.md)
