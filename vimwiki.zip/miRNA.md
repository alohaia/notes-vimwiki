# miRNA

- 20~25 个[碱基](碱基.md)
- 不同[生物体](生物体.md)中普遍存在

See Also: [RNA干扰](RNA干扰.md)
