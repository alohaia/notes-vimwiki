# npm 和 yarn 换源

```bash
npm config get registry
npm install 包的名字 --registry https://registry.npm.taobao.org
npm config set registry https://registry.npm.taobao.org

yarn config get registry
yarn install 包的名字 --registry https://registry.npm.taobao.org
yarn config set registry https://registry.npm.taobao.org
```
