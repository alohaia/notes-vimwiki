# RNA依赖的RNA聚合酶

RNA-dependent RNA polymerase, RNA pol, [RNA聚合酶](RNA聚合酶.md)

- [启动子](启动子.md)，不需要引物
- 解旋酶活性
