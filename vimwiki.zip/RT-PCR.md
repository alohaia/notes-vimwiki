# RT-PCR

- 总[RNA](RNA.md)
- [mRNA](mRNA.md)模板
- Oligo([dT](dT.md))/[随机引物](随机引物.md) [逆转录酶](逆转录酶.md) [cDNA](cDNA.md)

[Real-time PCR](Real-time_PCR.md)

See Also: [RT](RT.md) | [PCR](PCR.md)
