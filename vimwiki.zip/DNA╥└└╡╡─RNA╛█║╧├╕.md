# DNA依赖的RNA聚合酶

DNA-dependent RNA polymerase, RNA pol, [RNA聚合酶](RNA聚合酶.md)
