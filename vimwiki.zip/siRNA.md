# siRNA， 干扰小 RNA， small interfering RNA

## 特点
See Also: [miRNA](miRNA.md)


See Also: [RNA干扰](RNA干扰.md)
