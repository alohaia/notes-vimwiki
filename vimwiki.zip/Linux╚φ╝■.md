# Linux软件

kazam

flameshot

shotwell

feh

qv2ray

gpick

obsidian-appimage

typora


