# MySQL

> 被 Oracle 收购，有闭源的风险，使用 [MariaDB](MariaDB.md) 代替。
