# TATA盒

See Also: [Sp1](Sp1.md) | [GC序列](GC序列.md) | [T/CACC盒](T\/CACC盒.md)
