# β-N-糖苷键

β-N-glycosidic bond

- [核糖](核糖.md)：C-1'
- [碱基](碱基.md)
    - 嘌呤：N-9
    - 嘧啶：N-1
