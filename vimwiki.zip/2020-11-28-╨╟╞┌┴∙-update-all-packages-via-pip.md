# 2020-11-28-星期六-update-all-packages-via-pip

1. List outdate packages

```bash
pip list --outdated
```

1. Update them

```bask
pip install <package> --update
```
