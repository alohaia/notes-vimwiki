# RNA干扰，RNAi，RNA interfering

[miRNA](miRNA.md)、[siRNA](siRNA.md)介导的基因表达抑制作用
