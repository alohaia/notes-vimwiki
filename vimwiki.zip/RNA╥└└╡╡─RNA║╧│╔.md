# RNA依赖的RNA合成

RNA-dependent RNA synthesis，也称[RNA复制](RNA复制.md)

[RNA依赖的RNA聚合酶](RNA依赖的RNA聚合酶.md)
