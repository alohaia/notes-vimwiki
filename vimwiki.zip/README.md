My notes writeen via vimwiki
