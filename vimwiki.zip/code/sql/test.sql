use test;
show tables;
create table test(id int(3), name varchar(20));
drop table test;
show databases;
show tables;