function greeting ( name )
    print("Hello, "..name.."! I' aloha.")
end
