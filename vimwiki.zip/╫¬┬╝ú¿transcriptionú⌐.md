# 转录（transcription）

见[核糖核苷酸](核糖核苷酸.md)
